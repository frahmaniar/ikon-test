<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>login_button</name>
   <tag></tag>
   <elementGuidId>068c93d4-c8fe-4f50-97dd-de8128f1f873</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'btn-login']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>btn-login</value>
      <webElementGuid>34e4ca1b-5c51-4678-90cc-d02b477e7d15</webElementGuid>
   </webElementProperties>
</WebElementEntity>
