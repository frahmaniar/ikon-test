<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>passwordDemo_value</name>
   <tag></tag>
   <elementGuidId>846972f2-485b-4fb1-b348-1352db8ca905</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'demo_password_label']/following-sibling::input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id = 'demo_password_label']/following-sibling::input</value>
      <webElementGuid>2503203a-9509-439b-856a-c2fb7501b13e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
