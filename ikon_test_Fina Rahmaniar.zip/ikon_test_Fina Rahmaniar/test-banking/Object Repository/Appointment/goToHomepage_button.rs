<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>goToHomepage_button</name>
   <tag></tag>
   <elementGuidId>fce09cf7-8720-402c-8fce-ceda7c9a80ea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Go to Homepage' or . = 'Go to Homepage')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Go to Homepage</value>
      <webElementGuid>78e62202-2c47-44e1-a9e7-605cded07892</webElementGuid>
   </webElementProperties>
</WebElementEntity>
