<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>hongkongCura_optionValue</name>
   <tag></tag>
   <elementGuidId>d70c01bb-983e-4a04-8f53-7c436e450aaf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@value = 'Hongkong CURA Healthcare Center']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>Hongkong CURA Healthcare Center</value>
      <webElementGuid>955b1557-409e-46fc-a70e-14f6d87eacea</webElementGuid>
   </webElementProperties>
</WebElementEntity>
