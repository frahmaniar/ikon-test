<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>medicaid_option</name>
   <tag></tag>
   <elementGuidId>bc743e55-3a32-452b-8dde-f0bcfe11b432</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'radio_program_medicaid']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>radio_program_medicaid</value>
      <webElementGuid>fcfc6a06-2076-4a8e-9214-4da85aefdcdd</webElementGuid>
   </webElementProperties>
</WebElementEntity>
