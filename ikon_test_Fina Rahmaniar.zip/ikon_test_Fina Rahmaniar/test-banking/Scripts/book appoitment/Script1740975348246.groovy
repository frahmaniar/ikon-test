import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.callTestCase(findTestCase('login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Appointment/facility_field'))

WebUI.callTestCase(findTestCase('login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.verifyElementPresent(findTestObject('Appointment/hongkongCura_optionValue'), 0)

WebUI.click(findTestObject('Appointment/hongkongCura_optionValue'))

WebUI.click(findTestObject('Appointment/hospitalReadmission_checkBox'))

WebUI.click(findTestObject('Appointment/setDate_field'))

WebUI.setText(findTestObject('Appointment/setDate_field'), '04/03/2025')

WebUI.sendKeys(findTestObject('Appointment/setDate_field'), Keys.chord(Keys.ESCAPE))

WebUI.delay(2)

WebUI.click(findTestObject('Appointment/comment_field'))

WebUI.setText(findTestObject('Appointment/comment_field'), 'test')

WebUI.click(findTestObject('Appointment/book_appoitment'))

WebUI.delay(3)

WebUI.verifyElementPresent(findTestObject('Appointment/goToHomepage_button'), 0)

