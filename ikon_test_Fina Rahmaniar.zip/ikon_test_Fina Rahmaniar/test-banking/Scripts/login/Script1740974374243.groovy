import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://katalon-demo-cura.herokuapp.com/')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Login/makeAppoitment_button'))

WebUI.verifyElementPresent(findTestObject('Login/usernameDemo_value'), 0)

def username = WebUI.getAttribute(findTestObject('Login/usernameDemo_value'), 'value')

println('username: ' + username)

WebUI.verifyElementPresent(findTestObject('Login/passwordDemo_value'), 0)

def password = WebUI.getAttribute(findTestObject('Login/passwordDemo_value'), 'value')

println('password: ' + password)

WebUI.setText(findTestObject('Login/username_field'), username)

WebUI.setText(findTestObject('Login/password_field'), password)

WebUI.click(findTestObject('Login/login_button'))

WebUI.verifyElementPresent(findTestObject('Appointment/facility_field'), 0)

not_run: WebUI.closeBrowser()

